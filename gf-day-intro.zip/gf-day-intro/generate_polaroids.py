"""
generate_polaroids.py

Creates placeholder "photo" tiles for the polaroid wall behind the flower
curtain. These are obviously-placeholder gradient tiles with a small heart
mark -- swap the files in /photos/ for real couple photos later (keep the
same filenames, or update the list in index.html).

Run:
    python3 generate_polaroids.py
Produces:
    photos/photo01.jpg ... photo16.jpg
"""

import math
import os
import random
from PIL import Image, ImageDraw

random.seed(3)

OUT_DIR = "photos"
os.makedirs(OUT_DIR, exist_ok=True)

W, H = 700, 860  # portrait photo area (polaroid framing added via CSS)

GRADIENT_PAIRS = [
    ((196, 74, 88), (223, 140, 123)),
    ((99, 128, 176), (150, 111, 168)),
    ((129, 156, 122), (233, 196, 106)),
    ((185, 58, 66), (233, 196, 106)),
    ((150, 111, 168), (99, 128, 176)),
    ((223, 140, 123), (233, 196, 106)),
    ((129, 156, 122), (99, 128, 176)),
    ((185, 58, 66), (150, 111, 168)),
]


def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def make_gradient(c1, c2, angle_variety):
    img = Image.new("RGB", (W, H))
    px = img.load()
    ang = math.radians(angle_variety)
    dx, dy = math.cos(ang), math.sin(ang)
    for y in range(H):
        for x in range(0, W, 2):
            t = ((x * dx + y * dy) / (W * abs(dx) + H * abs(dy) + 1e-6) + 1) / 2
            t = max(0, min(1, t))
            col = lerp(c1, c2, t)
            px[x, y] = col
            if x + 1 < W:
                px[x + 1, y] = col
    return img


def draw_heart(draw, cx, cy, size, color):
    pts = []
    for t in range(0, 63):
        tt = t / 62 * 2 * math.pi
        x = 16 * math.sin(tt) ** 3
        y = 13 * math.cos(tt) - 5 * math.cos(2 * tt) - 2 * math.cos(3 * tt) - math.cos(4 * tt)
        pts.append((cx + x * size / 16, cy - y * size / 16))
    draw.polygon(pts, fill=color)


def main():
    for i in range(16):
        c1, c2 = GRADIENT_PAIRS[i % len(GRADIENT_PAIRS)]
        angle = random.uniform(0, 180)
        img = make_gradient(c1, c2, angle)
        d = ImageDraw.Draw(img, "RGBA")
        # soft vignette
        for r in range(0, 260, 4):
            alpha = int(35 * (r / 260))
            d.ellipse([-r + W / 2 - 260, -r + H / 2 - 260, r + W / 2 + 260, r + H / 2 + 260],
                      outline=(0, 0, 0, alpha))
        draw_heart(d, W / 2, H / 2, 70, (255, 255, 255, 130))
        img.save(os.path.join(OUT_DIR, f"photo{i+1:02d}.jpg"), quality=87)

    print(f"Saved 16 placeholder photos to ./{OUT_DIR}/")


if __name__ == "__main__":
    main()

"""
generate_pattern.py

Procedurally paints an original, hand-drawn-feeling flower field and
slices it into two panels (left/right) used as the "curtain" background
for the intro animation. Nothing here is copied from any reference image —
every flower is built from primitive shapes with randomized palette,
size and rotation.

Run:
    python3 generate_pattern.py
Produces:
    left.png, right.png  (used by index.html)
"""

import math
import random
from PIL import Image, ImageDraw, ImageFilter

random.seed(11)

# ---- canvas ---------------------------------------------------------------
PANEL_W, PANEL_H = 1000, 1200
CANVAS_W, CANVAS_H = PANEL_W * 2, PANEL_H
SUPERSAMPLE = 2

W, H = CANVAS_W * SUPERSAMPLE, CANVAS_H * SUPERSAMPLE

PALETTE = [
    (185, 58, 66),    # deep rose red
    (223, 140, 123),  # terracotta pink
    (233, 196, 106),  # butter yellow
    (129, 156, 122),  # sage green
    (99, 128, 176),   # periwinkle blue
    (150, 111, 168),  # dusty violet
    (247, 243, 233),  # cream white
    (168, 178, 158),  # eucalyptus grey-green
]
DARK_CENTER = [(40, 28, 22), (54, 34, 22), (30, 30, 20)]


def paste_rotated_ellipse(base, cx, cy, w, h, angle_deg, color):
    pad = 4
    img = Image.new("RGBA", (int(w) + pad * 2, int(h) + pad * 2), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse([pad, pad, pad + w, pad + h], fill=color + (255,))
    img = img.rotate(angle_deg, expand=True, resample=Image.BICUBIC)
    base.paste(img, (int(cx - img.width / 2), int(cy - img.height / 2)), img)


def peony(base, cx, cy, r, color, petals=7, rotation=0):
    """Rounded, multi-layer peony/ranunculus style bloom."""
    draw = ImageDraw.Draw(base)
    for layer in range(3):
        layer_r = r * (1 - layer * 0.24)
        petal_len = layer_r * 1.05
        petal_w = layer_r * 0.68
        shade = tuple(max(0, min(255, c + (layer * 14 - 10))) for c in color)
        offset = rotation + (360 / petals / 2 if layer % 2 else 0)
        for i in range(petals):
            ang = offset + i * (360 / petals)
            rad = math.radians(ang)
            px = cx + math.cos(rad) * layer_r * 0.5
            py = cy + math.sin(rad) * layer_r * 0.5
            paste_rotated_ellipse(base, px, py, petal_w, petal_len, ang + 90, shade)
    cc = random.choice(DARK_CENTER)
    cr = r * 0.2
    draw.ellipse([cx - cr, cy - cr, cx + cr, cy + cr], fill=cc)
    for _ in range(10):
        a = random.uniform(0, math.tau)
        d2 = random.uniform(0, cr)
        fx, fy = cx + math.cos(a) * d2, cy + math.sin(a) * d2
        draw.ellipse([fx - 1.6, fy - 1.6, fx + 1.6, fy + 1.6], fill=(235, 228, 200))


def poppy(base, cx, cy, r, color, petals=5, rotation=0):
    """Fewer, broader petals with a bold dark stamen center (poppy/anemone style)."""
    draw = ImageDraw.Draw(base)
    petal_len = r * 1.15
    petal_w = r * 0.95
    for i in range(petals):
        ang = rotation + i * (360 / petals)
        rad = math.radians(ang)
        px = cx + math.cos(rad) * r * 0.42
        py = cy + math.sin(rad) * r * 0.42
        paste_rotated_ellipse(base, px, py, petal_w, petal_len, ang + 90, color)
    cr = r * 0.3
    draw.ellipse([cx - cr, cy - cr, cx + cr, cy + cr], fill=(20, 16, 14))
    for i in range(14):
        ang = math.radians(i * (360 / 14))
        x1, y1 = cx + math.cos(ang) * cr * 0.5, cy + math.sin(ang) * cr * 0.5
        x2, y2 = cx + math.cos(ang) * cr * 1.15, cy + math.sin(ang) * cr * 1.15
        draw.line([x1, y1, x2, y2], fill=(70, 55, 30), width=2)


def build_scene():
    base = Image.new("RGBA", (W, H), (250, 247, 238, 255))

    spacing = 130 * SUPERSAMPLE  # smaller spacing relative to size = denser overlap
    flowers = []
    y = -spacing / 2
    row = 0
    while y < H + spacing:
        x_off = (spacing / 2) if row % 2 else 0
        x = -spacing / 2 + x_off
        while x < W + spacing:
            jitter_x = random.uniform(-0.4, 0.4) * spacing
            jitter_y = random.uniform(-0.4, 0.4) * spacing
            size = random.uniform(1.05, 1.55) * spacing  # big overlap, fuller coverage
            flowers.append((x + jitter_x, y + jitter_y, size))
            x += spacing
        y += spacing * 0.82
        row += 1

    flowers.sort(key=lambda f: -f[2])
    for (fx, fy, size) in flowers:
        color = random.choice(PALETTE)
        rotation = random.uniform(0, 360)
        if random.random() < 0.42:
            poppy(base, fx, fy, size / 2, color, petals=random.choice([5, 6]), rotation=rotation)
        else:
            peony(base, fx, fy, size / 2, color, petals=random.choice([6, 7, 8]), rotation=rotation)

    return base.convert("RGB")


def main():
    scene = build_scene()
    scene = scene.filter(ImageFilter.SMOOTH_MORE)
    scene = scene.resize((CANVAS_W, CANVAS_H), Image.LANCZOS)

    left = scene.crop((0, 0, PANEL_W, PANEL_H))
    right = scene.crop((PANEL_W, 0, CANVAS_W, PANEL_H))

    left.save("left.png")
    right.save("right.png")
    print("Saved left.png and right.png", left.size, right.size)


if __name__ == "__main__":
    main()
